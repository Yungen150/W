import { PieChart, Pie, Cell, ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

const trafficData = [
  { name: 'Direct', value: 35, color: '#4f46e5' },
  { name: 'Social Media', value: 25, color: '#06b6d4' },
  { name: 'Search Engines', value: 30, color: '#10b981' },
  { name: 'Email', value: 10, color: '#f59e0b' },
];

const performanceData = [
  { name: 'Jan', visitors: 4000, pageViews: 2400, bounceRate: 45 },
  { name: 'Feb', visitors: 3000, pageViews: 1398, bounceRate: 42 },
  { name: 'Mar', visitors: 2000, pageViews: 9800, bounceRate: 38 },
  { name: 'Apr', visitors: 2780, pageViews: 3908, bounceRate: 35 },
  { name: 'May', visitors: 1890, pageViews: 4800, bounceRate: 40 },
  { name: 'Jun', visitors: 2390, pageViews: 3800, bounceRate: 37 },
];

export default function Analytics() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Analytics</h2>
        <p className="text-gray-600 mt-1">Detailed insights into your application performance.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Traffic Sources</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={trafficData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                dataKey="value"
                label={({ name, percent }) => `${name} ${((percent ?? 0) * 100).toFixed(0)}%`}
              >
                {trafficData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Metrics</h3>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Area type="monotone" dataKey="visitors" stackId="1" stroke="#4f46e5" fill="#4f46e5" fillOpacity={0.6} />
              <Area type="monotone" dataKey="pageViews" stackId="1" stroke="#06b6d4" fill="#06b6d4" fillOpacity={0.6} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wide">Page Views</h4>
          <p className="text-3xl font-bold text-gray-900 mt-2">127,543</p>
          <p className="text-sm text-green-600 mt-2">+12% from last month</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wide">Unique Visitors</h4>
          <p className="text-3xl font-bold text-gray-900 mt-2">45,231</p>
          <p className="text-sm text-green-600 mt-2">+8% from last month</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h4 className="text-sm font-medium text-gray-500 uppercase tracking-wide">Bounce Rate</h4>
          <p className="text-3xl font-bold text-gray-900 mt-2">38.2%</p>
          <p className="text-sm text-red-600 mt-2">-3% from last month</p>
        </div>
      </div>
    </div>
  );
}